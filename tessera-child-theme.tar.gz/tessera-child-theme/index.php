<?php

require_once('tesseraThemePlugin.inc.php');

return new tesseraThemePlugin();

?>
