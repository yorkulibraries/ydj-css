Examples
========

The source code including examples can be downloaded from the
[release page at GitHub](https://github.com/jsor/jcarousel/releases).

* [Basic Carousel](basic/)
* [Connected Carousels](connected-carousels/)
* [Carousel using CSS3 Transitions](transitions/)
* [Responsive Carousel](responsive/)
* [Carousel using data-* attributes for initialization and configuration](data-attributes/)
* [Ajax Carousel](ajax/)
* [Vertical Carousel](vertical/)
* [Carousel Skeleton](skeleton/)
