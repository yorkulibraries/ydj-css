<?php

require_once('topiaThemePlugin.inc.php');

return new topiaThemePlugin();

?>
