<?php

require_once('spiThemePlugin.inc.php');

return new spiThemePlugin();

?>
