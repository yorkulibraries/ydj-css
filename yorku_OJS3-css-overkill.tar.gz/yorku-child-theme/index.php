<?php

require_once('YorkUThemePlugin.inc.php');

return new YorkUThemePlugin();

?>
