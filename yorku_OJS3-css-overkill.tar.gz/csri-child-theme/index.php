<?php

require_once('csriThemePlugin.inc.php');

return new csriThemePlugin();

?>
