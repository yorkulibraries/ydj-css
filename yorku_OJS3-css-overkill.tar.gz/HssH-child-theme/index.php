<?php

require_once('HssHThemePlugin.inc.php');

return new HssHThemePlugin();

?>
